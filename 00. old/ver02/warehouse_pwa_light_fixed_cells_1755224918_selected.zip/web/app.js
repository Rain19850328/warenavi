function occupancyRate(used, cap) {
  return cap > 0 ? (100 * used / cap) : 0;
}

function renderRack(cells) {
  const grid = document.querySelector('#rackGrid');
  grid.innerHTML = '';

  const heights = CONFIG.level_heights_cm;
  const sumH = Object.values(heights).reduce((a,b)=>a+b,0);

  for (let level = CONFIG.levels; level >= 1; level--) {
    const row = document.createElement('div');
    row.className = 'rackRow';
    row.style.height = `${100 * heights[level] / sumH}%`;

    for (let bay = 1; bay <= CONFIG.bays; bay++) {
      const ci = cells.find(c => c.level === level && c.bay === bay) || {total_cm3:0, capacity_cm3:1};
      const rate = Math.floor(occupancyRate(ci.total_cm3, ci.capacity_cm3));

      const c = document.createElement('div');
      c.className = 'cell';

      const c1 = document.createElement('div');
      c1.className = 'code';
      c1.textContent = `${bay}-${level}`;

      const c2 = document.createElement('div');
      c2.className = 'list';
      c2.textContent = `${rate}%`;

      const c3 = document.createElement('div');
      c3.className = 'foot';
      c3.textContent = `적재율: ${rate}%`;

      c.append(c1, c2, c3);

      // 선택 효과 토글
      c.addEventListener('click', () => {
        grid.querySelectorAll('.cell').forEach(el => el.classList.remove('selected'));
        c.classList.add('selected');
        showDetail(ci);
      });

      row.appendChild(c);
    }
    grid.appendChild(row);
  }
}

function showDetail(ci) {
  const detail = document.querySelector('#detailPanel');
  detail.textContent = `Bay: ${ci.bay || '-'}, Level: ${ci.level || '-'}, 적재율: ${Math.floor(occupancyRate(ci.total_cm3, ci.capacity_cm3))}%`;
}