// warehouse_pwa_light_glow_PATH_UPDATE_v1755585458 — search fixed (r5)
const API_BASE = '/api';
const sel = s => document.querySelector(s);
const fmtM3 = cm3 => (cm3/1_000_000).toFixed(2) + ' m³';
const CELL_BASE_HEIGHT = 580;

let CONFIG = null;
let CELLS = [];
let CURRENT_ROW = null;
let CURRENT_CELL = null;

let __dlgOverlay = null;
function openDialog(el) {
  if (el && typeof el.showModal === 'function') { el.showModal(); return; }
  if (!el) return;
  __dlgOverlay = document.createElement('div');
  __dlgOverlay.className = 'backdrop';
  document.body.append(__dlgOverlay);
  el.setAttribute('open','');
}
function closeDialog(el) {
  if (el && typeof el.close === 'function') { el.close(); return; }
  if (!el) return;
  el.removeAttribute('open');
  if (__dlgOverlay) { __dlgOverlay.remove(); __dlgOverlay = null; }
}
function ensureInboundDialog() {
  let dlg = document.getElementById('dlgInbound');
  if (!dlg) {
    dlg = document.createElement('dialog');
    dlg.id = 'dlgInbound';
    dlg.innerHTML = `
      <form method="dialog" class="dialog">
        <h3 id="dlgTitle">입고</h3>
        <div class="row">
          <input id="dlgQuery" type="text" placeholder="SKU/상품명/위치코드" />
          <button id="dlgBtnSearch">검색</button>
        </div>
        <div class="list" id="dlgList"></div>
        <div class="row">
          <label>수량 <input id="dlgQty" type="number" min="1" step="1" value="100" /></label>
          <button id="dlgOk" value="ok">확인</button>
          <button id="dlgCancel">취소</button>
        </div>
      </form>`;
    document.body.append(dlg);
  }
  return dlg;
}

async function getJSON(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
async function postJSON(url, body) {
  const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

function occupancyRate(used, cap) { return cap <= 0 ? 0 : (used / cap) * 100.0; }

function colorByRate(total, cap) {
  const rate = cap <= 0 ? 0 : (total / cap) * 100;
  if (total <= 0) return {fill:'#ffffff',  border:'#cbd5e1'};
  if (rate <= CONFIG.rate_low_max)  return {fill:'#e0f2fe', border:'#3C8CC8'};
  if (rate <= CONFIG.rate_normal_max) return {fill:'#dcfce7', border:'#50A468'};
  return {fill:'#ffedd5', border:'#C88C3C'};
}

function buildLegend() {
  const legend = document.createElement('div');
  legend.className = 'legend';
  const entries = [
    {name:'빈칸', style:{background:'#ffffff', border:'#cbd5e1'}},
    {name:`저적재(≤${CONFIG.rate_low_max}%)`, style:{background:'#e0f2fe', border:'#3C8CC8'}},
    {name:`정상(${CONFIG.rate_low_max+1}–${CONFIG.rate_normal_max}%)`, style:{background:'#dcfce7', border:'#50A468'}},
    {name:`포화(>${CONFIG.rate_normal_max}%)`, style:{background:'#ffedd5', border:'#C88C3C'}},
  ];
  for (const e of entries) {
    const sw = document.createElement('div'); sw.className='sw';
    sw.style.background = e.style.background; sw.style.borderColor = e.style.border;
    const label = document.createElement('span'); label.textContent = e.name; label.style.marginLeft='6px';
    const box = document.createElement('div'); box.style.display='flex'; box.style.alignItems='center'; box.append(sw,label);
    legend.append(box);
  }
  return legend;
}

// Search partial match
function matchesQuery(ci, qUpper) {
  if (!qUpper) return true;
  if (ci.code && ci.code.toUpperCase().includes(qUpper)) return true;
  return ci.items.some(it =>
    (it.sku && it.sku.toUpperCase().includes(qUpper)) ||
    (it.name && it.name.toUpperCase().includes(qUpper))
  );
}

function renderRack() {
  const host = sel('#rack');
  host.innerHTML = '';
  host.append(buildLegend());

  const queryUpper = sel('#search').value.trim().toUpperCase();
  const fEmpty = sel('#fEmpty').checked;
  const fLow   = sel('#fLow').checked;
  const fMixed = sel('#fMixed').checked;

  const grid = document.createElement('div');
  grid.className = 'grid';

  const bays = Array.from({length: CONFIG.bays}, (_,i)=>i+1);
  const heights = CONFIG.level_heights_cm;
  const sumH = Object.values(heights).reduce((a,b)=>a+b,0);

  let firstSelectedCode = CURRENT_CELL ? CURRENT_CELL.code : null;
  let firstMatchEl = null;

  for (const bay of bays) {
    const bayDiv = document.createElement('div');
    bayDiv.className = 'bay';

    for (let level=CONFIG.levels; level>=1; level--){
      const ci = CELLS.find(c => c.bay===bay && c.level===level);
      const cell = document.createElement('div');
      cell.className = 'cell';
      const ph = Math.max(72, CELL_BASE_HEIGHT * (heights[level] / sumH));
      cell.style.height = ph + 'px';
      cell.style.minHeight = ph + 'px';
      cell.style.maxHeight = ph + 'px';
      cell.style.overflow = 'hidden';

      if (ci) {
        let hide = false;
        if (fEmpty && ci.total_cm3 !== 0) hide = true;
        if (fLow) {
          const r = occupancyRate(ci.total_cm3, ci.capacity_cm3);
          if (!(ci.total_cm3 > 0 && r <= CONFIG.rate_low_max)) hide = true;
        }
        if (fMixed && ci.kinds < 2) hide = true;

        const isMatch = matchesQuery(ci, queryUpper);
        if (queryUpper) {
          if (!isMatch) hide = true;
          else cell.classList.add('match');
        }

        if (hide) cell.style.opacity = 0.12;

        const {fill, border} = colorByRate(ci.total_cm3, ci.capacity_cm3);
        cell.style.background = fill; cell.style.borderColor = border;

        const c1 = document.createElement('div'); c1.className='code'; c1.textContent = ci.code;
        const linesAll = ci.items.map(it => `${it.sku}:${it.qty}`);
        const maxLines = 3;
        let lines = linesAll;
        if (linesAll.length > maxLines) {
          lines = linesAll.slice(0, maxLines).concat([`+${linesAll.length - maxLines} more`]);
        }

        const c2 = document.createElement('div'); c2.className='list'; c2.textContent = lines.join('\n');
        const c3 = document.createElement('div'); c3.className='foot';
        const rate = Math.floor(occupancyRate(ci.total_cm3, ci.capacity_cm3));
        c3.textContent = `적재율: ${rate}%`;

        cell.append(c1,c2,c3);

        cell.addEventListener('click', ()=> {
          document.querySelectorAll('.cell.selected').forEach(el=>el.classList.remove('selected'));
          cell.classList.add('selected');
          showDetail(ci);
        });

        if (!firstMatchEl && cell.classList.contains('match')) firstMatchEl = cell;

        if (firstSelectedCode && firstSelectedCode === ci.code) {
          setTimeout(()=>{
            cell.classList.add('selected');
            showDetail(ci);
          }, 0);
        }
      }
      bayDiv.append(cell);
    }
    grid.append(bayDiv);
  }
  host.append(grid);

  if (firstMatchEl) firstMatchEl.scrollIntoView({behavior:'smooth', block:'center', inline:'center'});
}

function showDetail(ci) {
  CURRENT_CELL = ci;
  sel('#selTitle').textContent = `선택된 위치: ${ci.code}`;
  const rate = Math.floor(occupancyRate(ci.total_cm3, ci.capacity_cm3));
  const remain = Math.max(0, ci.capacity_cm3 - ci.total_cm3);
  sel('#selStats').textContent = `적재율: ${rate}% · 용량: ${fmtM3(ci.capacity_cm3)} · 사용: ${fmtM3(ci.total_cm3)} · 남은공간: ${fmtM3(remain)}`;
  sel('#barFill').style.width = Math.min(100, rate) + '%';

  const tb = sel('#tblItems tbody');
  tb.innerHTML = '';
  for (const it of ci.items) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${it.sku}</td><td>${it.name}</td><td style="text-align:center">${it.qty}</td><td style="text-align:center">${fmtM3(it.used_cm3)}</td>`;
    tb.append(tr);
  }
  sel('#btnInbound').disabled = false;
}

async function loadCells() {
  const row = sel('#rowSelect').value;
  CURRENT_ROW = row;
  const data = await getJSON(`${API_BASE}/cells?row=${encodeURIComponent(row)}`);
  CELLS = data.cells;
  renderRack();
}

async function init() {
  try {
    CONFIG = await getJSON(`${API_BASE}/config`);
  } catch (err) {
    console.warn('config 불러오기 실패. 기본값으로 진행:', err);
    CONFIG = {
      rows: ['SR-01','SR-02','SR-03'],
      bays: 21,
      levels: 3,
      level_heights_cm: {1: 100, 2: 90, 3: 120},
      rate_low_max: 25,
      rate_normal_max: 70,
    };
  }
  CONFIG.level_heights_cm = CONFIG.level_heights_cm || {1: 100, 2: 90, 3: 120};

  const rs = sel('#rowSelect'); rs.innerHTML = '';
  for (const r of CONFIG.rows) {
    const o = document.createElement('option'); o.value = o.textContent = r; rs.append(o);
  }
  rs.value = CONFIG.rows[0];
  rs.addEventListener('change', loadCells);

  sel('#btnReload').addEventListener('click', loadCells);
  sel('#btnSearch').addEventListener('click', e => { e.preventDefault(); renderRack(); });
  sel('#search').addEventListener('keydown', e => { if (e.key==='Enter'){ e.preventDefault(); renderRack(); }});
  sel('#fEmpty').addEventListener('change', renderRack);
  sel('#fLow').addEventListener('change', renderRack);
  sel('#fMixed').addEventListener('change', renderRack);

  sel('#btnInbound').addEventListener('click', ()=>{
    try{ openInbound().catch(err=>alert('입고창 오류: '+(err.message||err))); }
    catch(e){ alert('입고창 오류: '+e); }
  });

  await loadCells();
}

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!window.__reloadedBySW) { window.__reloadedBySW = true; location.reload(); }
  });
}

function start() { init().catch(err => { console.error(err); alert('초기화 실패: ' + (err.message || err)); }); }
if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', start);
} else {
  start();
}
